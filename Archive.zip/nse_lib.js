const debugEnabled = true; // Set this to false to disable debug prints
const puppeteer = require('puppeteer');

function debugLog(...args) {
  if (debugEnabled) {
    console.log(...args);
  }
}

async function getOptionChain(instrument) {
  debugLog('Fetching option chain for instrument:', instrument);

  const browser = await puppeteer.launch({ headless: true });
  const page = await browser.newPage();

  try {
    const url = `https://www.nseindia.com/api/option-chain-equities?symbol=${instrument}`;
    await page.goto(url, { waitUntil: 'domcontentloaded' });

    const response = await page.evaluate(() => {
      return JSON.parse(document.querySelector('pre').textContent);
    });

    return response;
  } catch (error) {
    console.error('Error fetching data:', error.message);
    throw error;
  } finally {
    await browser.close();
  }
}

module.exports = getOptionChain;
